# P2.0 Workflow / Model Registry 验收包

本包为 P2.0 第一阶段的完整验收材料：报告、设计、审查、证据、配置与真机产物。

## 公网浏览/下载

- 首页：https://123.207.74.155/pub/p20/
- 本包最新版：https://123.207.74.155/pub/p20/bundle.zip

## 目录

| 路径 | 内容 |
|---|---|
| `P2.0-交付报告.md` | 5 项任务 × 10 项交付字段 |
| `P2.0-Workflow-Model-Registry-设计.md` | DB schema / REST API / 模块划分 / JSON 模板 |
| `01-调用关系审查.md` | UI / 脚本 / ComfyUI API 调用关系与输入输出 |
| `02-硬编码清单.md` | 固定模型 / 节点 / 参数逐条定位 |
| `调用关系图.png` / `.svg` | 调用关系图（1460×980） |
| `registry/` | 4 个模型 + 7 个工作流 + 兼容性矩阵配置 |
| `workflows/` | 新增的 portrait 图（任务 5A） |
| `specs/` | 4 个作业 spec（含故障注入用例） |
| `artifacts/` | 3 张真实 GPU 产物 PNG |
| `test-evidence/` | 测试汇总、作业台账、故障注入、API 响应 |
| `task5b-*.sha256` / `task5b-hash-proof.txt` | 只改配置不动核心代码的哈希证明 |
| `下载与预览.md` | 公网链接索引 |

## 结论速览

- P2.0 测试 60/60；P2 42/42；P1 13 例 12 PASS / 1 SKIP / 0 FAIL
- `p20ctl validate`：7 workflows / 4 models，verified 4、equivalent 2、experimental 1、incompatible 0
- 3 个真实作业全部 DONE + PASS，总花费 ¥0.2150
- 故障注入：`SUBMITTED → FAILED_RUN → RELEASING → FAILED`，实例已销毁，无残留
- 任务 5B 只新增配置：37 个核心文件 sha256 前后完全一致
